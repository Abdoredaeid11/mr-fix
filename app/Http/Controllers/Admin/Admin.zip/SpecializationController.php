<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Specialization;
use Illuminate\Http\Request;

class SpecializationController extends Controller
{
    //
    public function index()
    {
        $specializations = Specialization::with('category')->paginate(10);
        return view('admin.specializations.index', compact('specializations'));
    }
    public function create()
    {
        $categories = Category::all();
        return view('admin.specializations.add', compact('categories'));
    }
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'category_id' => 'required|exists:categories,id',
        ]);

        Specialization::create($request->all());

        return redirect()->route('specialization.index')->with('success', 'Specialization created successfully.');
    }
    public function edit($id)
    {
        $specialization = Specialization::findOrFail($id);
        $categories = Category::all();
        return view('admin.specializations.edit', compact('specialization', 'categories'));
    }
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'category_id' => 'required|exists:categories,id',
        ]);

        $specialization = Specialization::findOrFail($id);
        $specialization->update($request->all());

        return redirect()->route('specialization.index')->with('success', 'Specialization updated successfully.');
    }
    public function delete($id)
    {
        $specialization = Specialization::findOrFail($id);
        $specialization->delete();
        return redirect()->route('specialization.index')->with('success', 'Specialization deleted successfully.');
    }

}
