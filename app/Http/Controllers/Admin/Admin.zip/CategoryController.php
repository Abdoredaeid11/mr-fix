<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class CategoryController extends Controller
{
    public function index(){
        $categories = Category::all();
        return $categories;
    }

    public function store(Request $request){

        $slug = Str::slug($request->name);
        $category = Category::create([
            'name' => $request->name,
            'name_ar' => $request->name_ar,
            'slug' => $slug
        ]);
        return $category;
    }

    public function update(Request $request,$id){
        $category = Category::findOrFail($id);
        $category->update($request->all());
        return $category;
    }

    public function delete($id){
        $category = Category::findOrFail($id)->delete();
        return $category;
    }
}
