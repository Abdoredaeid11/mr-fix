<?php

namespace App\Http\Controllers\API\V2;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\WorkerAddress;
use App\Models\WorkerProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;


class UserController extends Controller
{
    //
public function update_profile(Request $request){
        $validator = Validator::make($request->all(), [
            'national_id' => 'required|numeric|digits:14',
            'age' => 'required|numeric|digits:2',
            'experiance' => 'nullable|numeric|digits:2',
            'info' => 'nullable|string|max:500',
            'price' => 'required|numeric|min:0'
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $worker = auth('user')->user();
        $profile = new WorkerProfile();
        $profile->worker_id = $worker->id;
        $profile->national_id = htmlentities($request->national_id);
        $profile->age = htmlentities($request->age);
        $profile->experiance = htmlentities($request->experiance);
        $profile->info = htmlentities($request->info);
        $profile->price = htmlentities($request->price);
        $profile->status = 'pending';
        $profile->save();

        return response()->json(['message' => 'Worker Profile Updated'], 200);
    }

      public function add_address(Request $request){
        $validator = Validator::make($request->all(), [
            'address' => 'required|string|max:255',
            'country' => 'nullable|string|max:255',
            'region' =>  'nullable|string|max:255',
            // 'latitude' => 'nullable|numeric',
            // 'longitude' => 'required|numeric'
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $worker = $request->user('user');
        if (!$worker) {
            return response()->json(['message' => 'Worker not found'], 404);
        }
        $addressCount = WorkerAddress::where('worker_id', $worker->id)->count();
        if ($addressCount >= 3) {
            return response()->json(['message' => 'A worker can only have up to 3 addresses'], 403);
        }
        // if ($request->defualt) {
        //     WorkerAddress::where('worker_id', $worker->id)->update(['defualt' => 0]);
        // }
           // If this is the first address, set it as defualt
    $isDefualt = $addressCount === 0 ? 1 : ($request->defualt ? 1 : 0);

    // If a new defualt address is set, reset others
    if ($isDefualt) {
        WorkerAddress::where('worker_id', $worker->id)->update(['defualt' => 0]);
    }

        $address = new WorkerAddress();
        $address->worker_id = $worker->id;
        $address->address = htmlentities($request->address);
        $address->country = htmlentities($request->country);
        $address->region = htmlentities($request->region);
        $address->latitude = htmlentities($request->latitude);
        $address->longitude = htmlentities($request->longitude);
        $address->defualt = $isDefualt;
        $address->save();

        return response()->json(['message' => 'Worker Address Added'], 200);
    }

      public function get_user(Request $request,$id)
    {
    $user = User::findOrFail($id);
        return response()->json(['user' => $user], 200);
    }

}
