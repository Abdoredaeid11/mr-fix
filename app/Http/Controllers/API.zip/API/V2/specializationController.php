<?php

namespace App\Http\Controllers\API\V2;

use App\Http\Controllers\Controller;
use App\Models\Specialization;
use Illuminate\Http\Request;

class specializationController extends Controller
{
    //
    public function index()
    {
        $specializations =Specialization::with('category')->get();
        
        return response()->json([
            'specializations' => $specializations
        ]);
    }
}
