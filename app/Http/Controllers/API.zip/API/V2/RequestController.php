<?php

namespace App\Http\Controllers\API\V2;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\RequestModel;
use App\Models\User;

class RequestController extends Controller
{
    //
        public function index()
    {
        $user = User::find(1);
        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }
        if($user->role=='user'){
            $request= $user->requestsAsClient()->get();
        }else if($user->role=='worker'){
            $request= $user->requestsAsProvider()->get();
        }else{
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        return response()->json($request);
    }
}
