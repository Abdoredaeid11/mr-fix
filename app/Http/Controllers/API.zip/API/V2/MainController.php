<?php
namespace App\Http\Controllers\API\V2;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Worker;
use App\Models\Category;
use Illuminate\Support\Facades\DB;

class MainController extends Controller
{

    public function getAllCategoriesAndWorkers(Request $request)
        {

            $request->validate([
                'radius' => 'nullable|numeric|min:1',
                'per_page' => 'nullable|integer|min:1'
            ]);

            $user = $request->user('user');
            $user_latitude = $user->latitude;
            $user_longitude = $user->longitude;

            $radius = $request->radius ?? 10;
            $perPage = $request->per_page ?? 12;

            $workers = User::selectRaw("
                users.*,
                ( 6371 * acos( cos( radians(?) ) * cos( radians( latitude ) ) *
                cos( radians( longitude ) - radians(?) ) +
                sin( radians(?) ) * sin( radians( latitude ) ) ) ) AS distance
            ", [$user_latitude, $user_longitude, $user_latitude])
            ->where('role', 'worker') // فلترة المستخدمين اللي هم عمال فقط
            ->where('status', 'active') // اختيار النشطين فقط
            ->having('distance', '<=', $radius)
            ->orderBy('distance')
            ->paginate($perPage);

            return response()->json([
                'workers' => $workers
            ]);
        }
        public function getAllCategories()
        {
            $categories = Category::with('specializations')->get();

            return response()->json([
                'categories' => $categories
            ]);
        }
}
