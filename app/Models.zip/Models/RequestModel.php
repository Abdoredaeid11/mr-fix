<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RequestModel extends Model
{
    use HasFactory;
        protected $table = 'requests';

    public function client()
{
    return $this->belongsTo(User::class, 'client_id');
}

public function provider()
{
    return $this->belongsTo(User::class, 'provider_id');
}

public function category()
{
    return $this->belongsTo(Category::class);
}
}
